<div class="container">
    <!-- Static navbar -->


    <nav class="navbar navbar-inverse">
        <div class="container-fluid">
            <div class="navbar-header">
                <a class="navbar-brand" href="home.php">Cricket Analytics</a>
            </div>
            <ul class="nav navbar-nav">
                <li ><a href="home.php">Home</a></li>
                <li><a href="ViewMatch.php">Matches</a></li>

                <li><a href="viewAllTeams.php">Teams</a></li>
                <li><a href="ViewPlayer.php">Players</a></li>
                <li><a href="viewVenue.php">Venue</a></li>
                <li><a href="viewumpire.php">Umpire</a></li>
                <li><a href="viewfixture.php.">Fixtures</a></li>
            </ul>
        </div>
    </nav>
    <!-- Main component for a primary marketing message or call to action -->

</div> <!-- /container -->
<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

